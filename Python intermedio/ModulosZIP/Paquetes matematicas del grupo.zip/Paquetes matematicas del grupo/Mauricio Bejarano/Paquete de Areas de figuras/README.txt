Instructivo para el uso del paquete de matematicas de areas:

1- Recuerde NO ingresar valores no numericos cuando el programa le solicite algún dato, o ocasionara el rompimiento de esté.
2- La figura que escoja esta reprentada por un numero si excede el maximo numero de opciones en le menu, provocará un error.
3- El programa le pedirá en primera instancia la medida de la base de la figura y la altura (De igual manera recuerde solo ingresar valores numericos).
4- Posteriormente a que el programa termine de pedirle los numeros, le dará su respectivo resultado y el programa se segura ejecutando hasta que usted elija la opción de salir.

