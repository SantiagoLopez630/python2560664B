
def area_triangulo(medida1,medida2):
    print('\nEl area de la figura es: ')
    print((medida1 * medida2 // 2))
    
    
def area_rectangulo(medida1,medida2):
    print('\nEl area de la figura es: ')
    print(medida1 * medida2)
      
def area_rombo(medida1,medida2):
    print('\nEl area de la figura es:')
    print(medida1 * medida2 //2)
      
      
      
def menu ():        
    while True:
        try:
            print()
            print("1- area del triangullo")
            print("2- area del rectangulo")
            print("3- area del rombo")
            print("4- salir")
            x=int(input("Selecciona una opción:   "))
            match x:
                case 1:
                    medida1=int(input('Ingrese el la base del triangulo: '))
                    medida2=int(input('Ingrese la altura del triangulo: '))
                    area_triangulo(medida1,medida2)
                case 2:
                    medida1=int(input('Ingrese el la base del rectangulo: '))
                    medida2=int(input('Ingrese la altura del rectangulo: '))
                    area_rectangulo(medida1,medida2)
                    break
                case 3:
                    medida1=int(input('Ingrese el la base del rombo: '))
                    medida2=int(input('Ingrese la altura del rombo: '))
                    area_rombo(medida1,medida2)
                case 4:
                    print('saliste')
                    break
                case 5:
                    print("Esta opcion aun no existe")
        except:
            print("Ingreso un valor no soportado por el sistema")