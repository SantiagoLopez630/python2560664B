
import area as a

print(a.menu())