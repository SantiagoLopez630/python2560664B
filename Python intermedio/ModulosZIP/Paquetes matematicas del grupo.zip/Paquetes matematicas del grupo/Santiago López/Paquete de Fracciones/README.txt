Instructivo para el uso del paquete de matematicas de fracciones:

1- Recuerde NO ingresar valores no numericos cuando el programa le solicite algún dato, o ocasionara el rompimiento de esté.
2- El número de fracciones que desea operar debe de ser mayor a 1, o si no, no se podrá calcular.
3- El programa le pedirá en primera instancia el numerador (el número de arriba de la fracción) y el denominador (el número de abajo de la fracción).
4- Posteriormente a que el programa termine de pedirle los numeros, le dará a escoger entre suma resta y multiplicacion reprentados con numeros y dependiendo a la opción escogida le dara su respectivo resultado.
5- Luego le preguntará si desea seguir utilizando la calculadora si es asi el ciclo se repetira una vez mas, sino el programa se cerrará (De igual manera recuerde solo ingresar valores numericos).
