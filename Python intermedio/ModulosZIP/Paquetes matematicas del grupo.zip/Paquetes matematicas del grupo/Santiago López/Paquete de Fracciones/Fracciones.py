import mate as m

while True:
    try:
        x=int(input('Cuantas fracciones desea operar? '))
        if x>1 :

            numeros=[]
            for i in range(x):
                numeros.append([])
                for j in range (1):
                    numeros[i].append(int(input('ingrese numerador: ')))
                    numeros[i].append(int(input('ingrese denominador: ')))

            print('Su fraccion es: ', numeros)
            print()
            

            print(m.fraccionar(numeros))

            while True:
                y=int(input('Desea seguir operando fracciones? \n 1- Si \n 2- No \n'))
                match y:
                    case 1:
                        break
                    case 2:
                        print('Adios, vuelve pronto :D')
                        break
                    case _:
                        print("Esta opcion no existe")
                        continue

            if y == 2:
                break

        else: 
            print('El numero de fracciones debe ser mayor a 1')
    except ValueError :
        print('Solo se aceptan valores nuemricos\n')
    except:
        print('Valor no soportado por el sistema')