from sys import path

path.append('C:\\Users\\palma\\OneDrive\\Documents\\Ivan Palmar\\SENA\\3er Trimestre\\Samuel Padilla\\Repositorio\\ADSO-B-INSTRUCTOR-SAMUEL\\9na Miscelania(Paquetes)\\Paquete_Proyecto')
import matematicas.area_pr.area

#print(matematicas.area_pr.area.a_elipse()) -Codigo de ejemplo:)